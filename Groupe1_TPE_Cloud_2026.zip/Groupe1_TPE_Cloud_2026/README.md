# TPE Cloud 2026 — Exercices 1, 2, 3

Ce dossier contient les solutions Python des exercices :
- Exercice 1 : Réversibilité de nombres
- Exercice 2 : Détection de doublons
- Exercice 3 : Convertisseur de date validée

Les scripts sont entièrement commentés et prêts à être testés.
